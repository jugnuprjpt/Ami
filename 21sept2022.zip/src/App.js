import './App.css';
import { BrowserRouter as Router, Route ,Link, Routes} from "react-router-dom";
import Header from './Component/Header';
import React from 'react';
import Main from './Layout/Main';
import OptionChart from './pages/OptionChart';
import MarketWatch from './pages/market-watch';
import Orderbook from './pages/order-book';
import Orderwindow from './pages/order-window';

function App() {
  return (
    <>  
  
  <div className="App">
    <Header />
      <Router>
        <Routes>
          <Route  path="/" element={<Main/>} />
          <Route  path="OptionChart" element={<OptionChart/>} />
          <Route  path="MarketWatch" element={<MarketWatch/>} />
          <Route  path="Orderbook" element={<Orderbook/>} />
          <Route  path="Orderwindow" element={<Orderwindow/>} />
        </Routes>
 
      </Router>
      
    </div>


    </>
  );
}

export default App;
