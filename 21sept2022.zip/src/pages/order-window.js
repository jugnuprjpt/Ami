import React from 'react';
import Table from 'react-bootstrap/Table';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { Badge, Form } from 'react-bootstrap';
export default function Orderwindow() {
  return (
    <>
      <div className='container-fluid'>
        <div className='row lesspadding'>
          <div className='col-12 mt-3'>
            <Breadcrumb>
              <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
              <Breadcrumb.Item active>Order Window</Breadcrumb.Item>
            </Breadcrumb>
          </div>
        </div>
        <div className='row'>
          <div className='col-12'>

    <div className='box'>

    <h1 className='bluebdr' >ORDER 1</h1>
    
      <div className='row'>
        <div className='col-12'>

         <sapn className='selltext'>BUY </sapn>  <span className='font-bold' > NIFTY 16550 PUT 27 JAN </span>
        </div>
      </div>
      <div className='row'>
        <div className='col-xl'> <Table responsive hover size="sm" className='order-book-tb border bg-white'>
              <thead>
                <tr>
                  <th className='text-start' >BIDS</th>
                  <th>ORDERS</th>
                  <th className='text-start'>QTY</th>
                  <th>OFFERS</th>
                  <th>ORDERS</th>
                  <th>QTY</th>

                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className='text-start'>38.50</td>
                  <td><span>1</span></td>
                  <td className='blue-text'>50</td>
                  <td>38.70</td>
                  <td className='red-text'>3</td>
                  <td className='red-text' > 1650 </td>
                </tr>
              
              </tbody>
            </Table></div>
        <div className='col-sm-6 col-xl-2'><ul className='listitems d-flex flex-column'>
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >Last Price </span> <span>50</span></li>
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >  Open </span> <span>50</span></li>
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >  High </span> <span>50</span></li>

                                                    <li className='d-flex justify-content-between'><span className='grey-text' >Low</span> <span>50</span></li>

                                                    
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >Close</span> <span>50</span></li>
                                                    
                                                </ul></div>
        <div className='col-sm-6 col-xl-2'>
        <ul className='listitems d-flex flex-column'>
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >Volume </span> <span>50</span></li>
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >  LTQ</span> <span>50</span></li>
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >  Avg. Price </span> <span>50</span></li>

                                                    <li className='d-flex justify-content-between'><span className='grey-text' >LTT</span> <span>50</span></li>

                                                    
                                                    <li className='d-flex justify-content-between'><span className='grey-text' >OI</span> <span>50</span></li>
                                                    
                                                </ul>

        </div>
      </div>
    </div>

           
          </div>
        </div>
        <div className='row'>
          <div className='col-12'>
          <Form>
      {['radio'].map((type) => (
        <div key={`default-${type}`} className="mb-3">
          <Form.Check 
            type={type}
            id={`default-${type}`}
            label={`default ${type}`}
          />

          <Form.Check
            disabled
            type={type}
            label={`disabled ${type}`}
            id={`disabled-default-${type}`}
          />
        </div>
      ))}
    </Form>
          </div>
        </div>
      </div>

    </>
  )
}
