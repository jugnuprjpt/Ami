import React, { useCallback, useMemo, useState } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import Form from 'react-bootstrap/Form';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import DatalistInput, { useComboboxControls } from 'react-datalist-input';



const columnDefsMedalsIncluded = [
    { field: 'athlete' },
    { field: 'gold' },
    { field: 'silver' },
    { field: 'bronze' },
    { field: 'total' },
    { field: 'age' },
    { field: 'country' },
    { field: 'sport' },
    { field: 'year' },
    { field: 'date' },
];

const colDefsMedalsExcluded = [
    { field: 'athlete' },
    { field: 'age' },
    { field: 'country' },
    { field: 'sport' },
    { field: 'year' },
    { field: 'date' },
];

export default function OptionChart() {

    const containerStyle = useMemo(() => ({ width: 'calc(100vw-20)', height: '80vh' }), []);
    const gridStyle = useMemo(() => ({ height: '80vh', width: 'calc(100vw-20)' }), []);
    const InitialRowData = [
        { "nge%": "Porsche", "OI-lakh": "Boxter", "LTP(Chg %)": 72000, "Strike": 55, "IV": "df", "LTP(Chg %)": "dsf", "LTP(Chg %)": "kl", "OIchange%": "sdf" },
        { "nge%": "Porsche", "OI-lakh": "Boxter", "LTP(Chg %)": 72000, "Strike": 55, "IV": "df", "LTP(Chg %)": "dsf", "LTP(Chg %)": "kl", "OIchange%": "sdf" },
        { "nge%": "Porsche", "OI-lakh": "aater", "LTP(Chg %)": 72000, "Strike": 55, "IV": "df", "LTP(Chg %)": "dsf", "LTP(Chg %)": "kl", "OIchange%": "sdf" },
        { "nge%": "Porsche", "OI-lakh": "Boxter", "LTP(Chg %)": 72000, "Strike": 55, "IV": "df", "LTP(Chg %)": "dsf", "LTP(Chg %)": "kl", "OIchange%": "sdf" },
        { "nge%": "Porsche", "OI-lakh": "Boxter", "LTP(Chg %)": 72000, "Strike": 55, "IV": "df", "LTP(Chg %)": "dsf", "LTP(Chg %)": "kl", "OIchange%": "sdf" }

    ];
    const [rowData, setRowData] = useState(InitialRowData);
    console.log(rowData)
    const [columnDefs, setColumnDefs] = useState([
        {
            headerName: 'Calls',
            children: [
                {
                    field: 'nge%',
                },
                {
                    field: 'OI-lakh',
                },
                {
                    field: 'LTP(Chg %)',
                },
                {
                    field: 'Strike',
                    filter: 'agNumberColumnFilter',
                },

            ],
        },
        {
            headerName: 'Puts',
            children: [
                { field: 'IV', width: 140 },
                {

                    field: 'LTP(Chg %)',
                },
                {

                    field: 'LTP(Chg %)',


                },
                {

                    field: 'OIchange%',

                }

            ],
        },
    ]);
    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            resizable: true,
            // filter: true,
        };
    }, []);



    const onGridReady = useCallback((params) => {
        fetch('https://www.ag-grid.com/example-assets/olympic-winners.json')
            .then((resp) => resp.json())
            .then((data) => setRowData(data));
    }, []);

    const { setValue, value } = useComboboxControls({ initialValue: 'Nifty' });

    return (
        <>
            <div className='container-fluid'>
                <div className='row lesspadding'>
                    <div className='col-12 mt-3'>
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Home</Breadcrumb.Item>

                            <Breadcrumb.Item active>Option Chart</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                </div>

                <div className='bg-white p-2 option-chart-det'>
                    <div className='row lesspd'>
                        <div className='col-auto border-end'>
                            <div className='d-flex align-items-center'>
                                <i className="fa-solid fa-magnifying-glass me-2 searchicon"></i>

                                <DatalistInput className='datalist-container'
                                    value={value}
                                    setValue={setValue}
                                    label="Select ice cream flavor"
                                    showLabel={false}
                                    items={[
                                        { id: 'Nifty', value: 'Nifty' },
                                        { id: 'BankNifty', value: 'BankNifty' },

                                    ]}

                                />

                                {/* <input className='form-control border-0 me-2 sminput'   list="languageList" />
                                <datalist id="languageList">
<option value="Nifty" />
<option value="BankNifty" />

</datalist>  */}
                                <img src='./assets/img/graph.png' className='me-2' />
                                <img src='./assets/img/infoimg.png' className='me-2' />
                            </div>
                        </div>
                        <div className='col-auto border-end d-flex align-items-center'>ATM IV 26.8  <span className='gn-text d-flex align-items-center'> +10.6 </span></div>
                        <div className='col-auto border-end d-flex align-items-center'>IV Chart</div>
                        <div className='col-auto border-end d-flex align-items-center'>Analyze OI</div>
                        <div className='col-auto border-end d-flex align-items-center'>
                            <Form>
                                <Form.Check
                                    label="Per lot"
                                    type="switch"
                                    id="custom-switch"

                                />

                            </Form>
                        </div>
                        <div className='col-auto border-end'>
                            <label>Expiry</label>
                            <select className='form-select form-select-sm small-sel'>
                                <option>11</option>
                                <option>11</option>
                                <option>11</option>
                            </select></div>

                        <div className='col-auto ms-auto d-flex align-items-center'>

                            <Dropdown className="d-inline mx-2 settinglist" autoClose="outside" align="end">
                                <Dropdown.Toggle id="dropdown-autoclose-outside" className="setting-btn" >
                                    Setting
                                </Dropdown.Toggle>

                                <Dropdown.Menu className='dropmenucl p-3'>
                                    <div className='row'>
                                        <div className='col-12 text-end'>
                                            <button className='btn btn-sm btn-outline-primary ms-auto rounded-bl-btn'> Reset to default</button>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="d-none d-lg-block  col-lg-auto">
                                            <p>No. Of strikes</p>
                                            <div className='border strikes-detail position-relative overflow-hidden '>

                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="388" className="svg-img" ><path d="M.5 145h15m-15 36h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-42h15m-15 36h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15M.5 246h15m-15 36h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-6h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15 75h15m-15 36h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-6h15m-15 75h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15 27h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15 24h15m-15 3h15m-15-6h15m-15-3h15m-15-3h15m-15-33h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-6h15M.5 103h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15m-15-3h15M.5 7h15M.5 4h15M.5 1h15" stroke="#b3b3b3" fill="none" fillRule="evenodd" strokeLinecap="square" ></path></svg>
                                                <div className='d-flex flex-column button-div '>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        40
                                                    </button>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        30
                                                    </button>
                                                    <button className='btn btn-sm btn-outline-primary activecl'>
                                                        20
                                                    </button>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        10
                                                    </button>
                                                </div>
                                                <div className='strike-seprator'>

                                                </div>
                                                <div className='d-flex flex-column  button-div'>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        10
                                                    </button>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        20
                                                    </button>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        30
                                                    </button>
                                                    <button className='btn btn-sm btn-outline-primary'>
                                                        40
                                                    </button>
                                                </div>

                                            </div>
                                        </div>
                                        <div className='col-lg'>
                                            <Form>
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Dark Theme"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Volume"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="OI Change"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="OI Change %"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    label="IV"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Bid Offer"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Show 100 multiples only"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <p className='mt-2'>Greeks</p>
                                                <div className='row'>

                                                    <div className='col-6'>  <Form.Check
                                                        className='mb-2'
                                                        label="Delta"
                                                        type="switch"
                                                        id="custom-switch"

                                                    /></div>
                                                    <div className='col-6'>  <Form.Check
                                                        className='mb-2'
                                                        label="Gamma"
                                                        type="switch"
                                                        id="custom-switch"

                                                    /></div>
                                                </div>

                                                <div className='row'>

                                                    <div className='col-6'>  <Form.Check
                                                        className='mb-2'
                                                        label="Theta"
                                                        type="switch"
                                                        id="custom-switch"

                                                    /></div>
                                                    <div className='col-6'>  <Form.Check
                                                        className='mb-2'
                                                        label="Vega"
                                                        type="switch"
                                                        id="custom-switch"

                                                    /></div>
                                                </div>

                                                <p className='mt-2'>Premium Features</p>

                                                <Form.Check
                                                    className='mb-2'
                                                    label="Per Strike PCR"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Intrinsic Value(spot)"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Intrinsic Value(futures)"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="Time Value"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                                <Form.Check
                                                    className='mb-2'
                                                    label="POP(Probability of Profit)"
                                                    type="switch"
                                                    id="custom-switch"

                                                />
                                            </Form>
                                        </div>
                                    </div>


                                </Dropdown.Menu>
                            </Dropdown>

                        </div>



                    </div>
                </div>



                <div className='row lesspadding'>
                    <div className='col-12'>
                        <div style={containerStyle}>
                            <div style={gridStyle} className="ag-theme-alpine" >
                                <AgGridReact
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    defaultColDef={defaultColDef}></AgGridReact>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

          
        </>
    )
}
