import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import Dropdown from 'react-bootstrap/Dropdown';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

export default class header extends Component {
  render() {
    return (
      <Navbar collapseOnSelect expand="lg" className='topheader' >
          <Container  fluid> 
          <Navbar.Brand href="#home" className='order-1 order-lg-1 logo ' ><img src="/assets/img/smarttouch-logo.png" /></Navbar.Brand>

          <Navbar.Toggle aria-controls="responsive-navbar-nav"  className=' order-3 order-lg-2' />
          <Navbar.Collapse id="responsive-navbar-nav" className=' order-3 order-lg-2'>
            <Nav className="me-auto ms-auto">
              <Nav.Link href="#features">Trade  </Nav.Link>
              <Nav.Link href="#pricing">Analyse</Nav.Link>
              <NavDropdown title="Watchlist" id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">
                  Another action
                </NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">
                  Separated link
                </NavDropdown.Item>
              </NavDropdown>

              <Nav.Link href="#features">Positios</Nav.Link>
              <Nav.Link href="#features">Daily Market</Nav.Link>
            </Nav>



          </Navbar.Collapse>

          <Dropdown align="end" className="usercl order-2 order-lg-4"  >
            <Dropdown.Toggle id="dropdown-basic">
              <img src='/assets/img/user.png' />
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
              <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
              <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>

          </Container>
      </Navbar>
    )
  }
}
