import logo from "./logo.svg";
import "./App.css";

import Header from "./Component/Header/Header";
import Camera from "./Component/Camera/Camera";
import Button from "./Component/Button/Button";
import { BrowserRouter, Route, Routes } from "react-router-dom";

function App() {
  return (
    <>
      <div className="App">
        <BrowserRouter>
          <Header></Header>
          <Routes>
            <Route path="/" element={<Camera />} />
          </Routes>
          <Button></Button>
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
