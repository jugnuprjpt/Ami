import React from 'react'
 import Webcam from "react-webcam"; 
import { Link } from "react-router-dom";


const WebcamComponent = () => <Webcam />; 
const Camera = () => {
  return (
    <>
 <div class="card-group" style={{marginLeft:"20px",marginRight:"20px",padding:"20px"}}>
  <div class="card" >
    <div class="card-body" >
      <h5 class="card-title">In Time</h5>
    </div>
  </div>
  
  <div class="card text-center">
  <div class="card-body" >
    <h5 class="card-title text-left">Code Scanner</h5> 
    <div className='card-body'>
    </div>
    <a href="#" class="btn btn-success" style={{marginTop:"125px"}}>Request camera Permission</a>
   
    <Link to ="/" style={{textDecoration:"none"}}><li style={{listStyle:"none",marginTop:"10px"}}>Scan the image file</li></Link>
  </div>
</div>
<div class="card">
    <div class="card-body" >
      <h5 class="card-title">Out Time</h5>
    </div>
  </div>
  </div>
    </>
  )
}

export default Camera