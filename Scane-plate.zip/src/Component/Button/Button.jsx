import React from 'react'

const Button = () => {
  return (
    <>
    <div style={{padding:"5px"}}>
    <button type="button" class="btn btn-outline-success">Plate Number</button>
    &nbsp;  &nbsp;  &nbsp;
    <button type="button" class="btn btn-outline-success">Log</button>
    &nbsp;  &nbsp;  &nbsp;
    <button type="button" class="btn btn-outline-success">Large Retake</button>
    </div>
    </>
  )
}

export default Button